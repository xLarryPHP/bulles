const bulles = () => {
  const bulles = document.createElement("span");
  bulles.classList.add("bulles");
  document.body.appendChild(bulles);

  const size = Math.random() * 200 + 100 + "px";
  bulles.style.height = size;
  bulles.style.width = size;

  bulles.style.top = Math.random() * 100 + 50 + "%";
  bulles.style.left = Math.random() * 100 + "%";

  const plusMinus = Math.random() > 0.5 ? 1 : -1;
  bulles.style.setProperty("--left", Math.random() * 100 * plusMinus + "%");

  bulles.addEventListener("click", () => {
    counter--;
    counterDisplay.textContent = counter;
    bulles.remove();
  });

  setTimeout(() => {
    bulles.remove();
  }, 8000);
};



setInterval(bulles, 800);
