const BonusMaker = () => {
  const BonusMaker = document.createElement("span");
  BonusMaker.classList.add("BonusMaker");
  document.body.appendChild(BonusMaker);

  const size = 0.1 * 200 + 100 + "px";
  BonusMaker.style.height = size;
  BonusMaker.style.width = size;

  BonusMaker.style.top = Math.random() * 100 + 50 + "%";
  BonusMaker.style.left = Math.random() * 100 + "%";

  const plusMinus = Math.random() > 0.5 ? 1 : -1;
  BonusMaker.style.setProperty("--left", Math.random() * 100 * plusMinus + "%");

  BonusMaker.addEventListener("click", () => {
    counter = counter + 5;
    counterDisplay.textContent = counter;
    BonusMaker.remove();
  });

  setTimeout(() => {
    BonusMaker.remove();
  }, 3000);
};



setInterval(BonusMaker, rando(1000,15000));
